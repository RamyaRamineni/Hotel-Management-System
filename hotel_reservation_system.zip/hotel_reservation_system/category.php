<?php 
session_start();
$PHP_SELF = $_SERVER['PHP_SELF'];
$url = "$_SERVER[REQUEST_URI]";
$path = parse_url($url, PHP_URL_PATH);
$queryString = parse_url($url, PHP_URL_QUERY);
$returnURL = $path;
$sortBy = "1";
if(isset($_GET["sortBy"]))
    $sortBy = $_GET["sortBy"];

if(isset($_GET["search"]) && !empty(trim($_GET["search"])))
    $search = $_GET["search"];

if(isset($_GET["location"]) && !empty(trim($_GET["location"]))) 
   $location = $_GET["location"];

if(isset( $_POST["children"] ) )  
    $location = $_POST["location"];

if ($location == ""){
    $location = "Austin";
}
require("topMenu.php");
?>
<?php

STATIC $count = 0;
    $connect = mysqli_connect("localhost", "root", "root", "hotel_reservation_system","3309");    

    if(isset($_POST["checkin"]) && !empty($_POST["checkin"]) && isset($_POST["checkout"]) && !empty($_POST["checkout"])){

        $checkin = $_POST["checkin"]; //date('yyyy-mm-dd', ($_SESSION['checkin_unformat']));
        $checkout = $_POST["checkout"];
        $siteConfigurationObject->setCheckin($checkin);
        $siteConfigurationObject->setCheckout($checkout);                        
	}
	if(isset( $_POST["adults"] ) ){
	   $_SESSION['adults'] = $_POST["adults"];
	}
	if(isset( $_POST["children"] ) ){
	   $_SESSION['children'] = $_POST["children"];
	}
				    
?>
					
<div id="all">

        <div id="content">
            <div class="container">

                <div class="col-md-12">
                    <ul class="breadcrumb">
                        <li><a href="#">Home</a>
                        </li>
                        <li>Category</li>
                    </ul>
                </div>

                <div class="col-md-3">
                    
                    <div class="panel panel-default sidebar-menu">

                        <div class="panel-heading">
                            <h3 class="panel-title">Categories</h3>
                        </div>

                        <div class="panel-body">
                            <ul class="nav nav-pills nav-stacked category-menu">
                                <li>
                                    <a href= <?php echo "category.php?category=0&location=$location"?>>All Products </a>
                                </li>
                                <li>
                                    <a href=<?php echo "category.php?category=1&location=$location"?>>Single Room </a>
                                </li>
                                <li>
                                    <a href=<?php echo "category.php?category=2&location=$location&location=$location"?>>Double Room</a>
                                </li>
                                <li>
                                    <a href=<?php echo "category.php?category=3&location=$location"?>>Suite</a>
                                </li>
                                <li>
                                    <a href=<?php echo "category.php?category=4&location=$location"?>>Premium Room</a>
                                </li>
                                <li>
                                    <a href=<?php echo "category.php?category=5&location=$location"?>>Deluxe Room</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="col-md-9">

                    <div class="box info-bar">
                        <div class="row">

                            <div class="col-sm-12 col-md-12  products-number-sort">
                                <div class="row">
                                    <form class="form-inline">
                                        <div class="col-md-6 col-sm-6">
                                            <!--
                                            <div class="products-number">
                                                <strong>Show</strong>  <a href="#" class="btn btn-default btn-sm btn-primary">2</a>  <a href="#" class="btn btn-default btn-sm">4</a>  <a href="#" class="btn btn-default btn-sm">All</a> products
                                            </div>
                                            -->
                                        </div>
                                        <div class="col-md-6 col-sm-6">
                                            <div class="products-sort-by">
                                                <strong>Sort by</strong>
                                                <select name="sort-by" class="form-control" id="sortBy">
                                                    <option value="1">Price (Low - High)</option>
                                                    <option value="2">Price (High - Low)</option>
                                                    <option value="3">Name (Ascending)</option>
                                                    <option value="4">Name (Descending)</option>
                                                </select>
                                                <a href="#" class="btn btn-default btn-sm btn-primary" onclick="return sortData();">Sort</a>
                                                <script type="text/javascript">
                                                    
                                                    function sortData(){
                                                        var currentURL = window.location.href;
                                                        
                                                        var sortBy = document.getElementById("sortBy").value;
                                                        var url1 = "", url2 = "";
                                                        var location = "<?php echo $location ?>";
                                                        if(currentURL.toLowerCase().indexOf("sortby") >= 0){
                                                            url1= currentURL.substring(0, currentURL.toLowerCase().indexOf("&sortby"));
                                                            currentURL = url1;                                                            
                                                        }                                                        
                                                        
                                                        window.location = currentURL + "?sortBy=" + sortBy + "&location=" + location ;                                                    
                                                        return true;
                                                    }
                                                    document.getElementById("sortBy").value="<?php echo $sortBy; ?>";
                                                </script>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                   <div class="row products">
                        <?php
						
						 $rec_limit = 2;
                         $count=0;
 
        				$conn = mysqli_connect("localhost","root","root","hotel_reservation_system",3309);

        				if (!$conn) {
        					die("Connection failed: " . mysqli_connect_error());
        					echo "Database Connection Error";
        				}
        				else{
        					if($siteConfigurationObject->isUserAdmin())
                                    $status = "0,1";                                    
                                else
                                    $status = "1";

                             $OrderBy = "ORDER BY PRICE ASC";

                                $searchQuery = "";

                                if(isset($search) && !empty($search)){
                                    $searchQuery = " AND room_type like '%$search%' ";
                                }
                                switch($sortBy){
                                    case 1 : $OrderBy = "ORDER BY PRICE ASC";
                                            break;
                                    case 2 : $OrderBy = "ORDER BY PRICE DESC";
                                            break;
                                    case 3 : $OrderBy = "ORDER BY room_type ASC";
                                            break;
                                    case 4 : $OrderBy = "ORDER BY room_type DESC";
                                            break;
                                    default : $OrderBy = "ORDER BY PRICE ASC";
                                            break;
                                }

                                
                                if(isset($_GET['category']))    
                                    $category = $_GET['category'];
                                else if (isset($_POST["category"])) {
                                    $category = $_POST["category"];
                                }
                                else {
                                    $category = 0;
                                }
                               
                                if($category == 0)
                                    $sql = "SELECT count(*) FROM rooms as r, hotels as h WHERE Status IN ($status) and r.hotel_id = h.hotel_id and h.location = '$location' $searchQuery $OrderBy" ;
                                    
                                else
                                    $sql = "SELECT count(*) FROM rooms as r, hotels as h, category_ref_table as c WHERE Status IN ($status) and r.hotel_id = h.hotel_id and h.location = '$location' and r.room_id = c.room_id and category_ID = $category $searchQuery $OrderBy" ;
                                    
                                $retval =  $conn->query($sql);                              
                                
                               
        						if(! $retval ) {
        							die('Could not get data: ' . mysqli_error());
        						 }
        						 $row = mysqli_fetch_array($retval, MYSQLI_NUM );
        						 $rec_count = $row[0];
        						 
        						  $pages = $rec_count / $rec_limit;
        						 
        						 if(isset($_GET{'page'})) {
        							$page = $_GET{'page'};
        							$offset = $rec_limit * ($page - 1);
        						 }else {
        							$page = 1;
        							$offset = 0;
        						 }
        						 
        						 $left_rec = $rec_count - (($page - 1) * $rec_limit);

        						if ( $category == 0)
                                {
                                    $query = "SELECT * FROM rooms as r, hotels as h WHERE Status IN ($status) $searchQuery and r.hotel_id = h.hotel_id and h.location = '$location' $OrderBy LIMIT $offset, $rec_limit";
                                }
                                else
                                {
                                  $query = "SELECT * FROM rooms as r, hotels as h, category_ref_table as c WHERE Status IN ($status) $searchQuery and r.hotel_id = h.hotel_id and h.location = '$location' and r.room_id = c.room_id and category_ID = $category $OrderBy LIMIT $offset, $rec_limit";
                                }
        						 $result = mysqli_query($conn, $query);

        				}
        				?>
        			
        					
        				 <?php while($datarow = mysqli_fetch_array($result)) : $count++;?>
                            <div class="col-md-4 col-sm-6 products">
                                <div class="product">
                                    <a href="detail.php">
                                        <img src="<?php echo "img/products/$datarow[image]" ?>" alt="" class="img-responsive">
                                    </a>
                                    <?php
                                    $totalroom = $datarow["total_room"];
                                    $roomtype = $datarow["room_type"];
                                    $query1 = "SELECT sum(rb.totalroombook) as booked_rooms FROM `roombook` as rb,`rooms` as r,`booking_dates` as bd,`bookings`as b, `hotels` as h WHERE b.booking_id = bd.booking_id and b.id =rb.id and bd.checkout_date< '$checkin' and r.room_id = b.room_id and r.room_type = '$roomtype' and h.location = '$location'";
                                    //echo $query1;
                                    $result1 = mysqli_query($conn, $query1);
                                    while($datarow1 = mysqli_fetch_array($result1)) { 
                                        $bookedrooms = $datarow1['booked_rooms'];
                                        
                                    }
                                    $availablerooms = $totalroom - $bookedrooms;
                                    ?>
                                    <div class="text">
                                        <input type='hidden' name='loginModalSubmit' id='loginModalSubmit' value=<?php echo $datarow["room_id"] ?> />
                                        <h3><a href=<?php echo 'detail.php?roomId='.$datarow["room_id"] ?> ><?php echo $datarow["room_type"] ?></a></h3>
                                        <p class="price">
                                            <?php echo "$".$datarow["price"]; ?><br>
                                            <?php if($availablerooms > 0) echo "Rooms Available: ",$availablerooms; else echo "Not Available"; ?>
                                        </p>
                                        <p class="buttons">
											<a href=<?php echo 'detail.php?roomId='.$datarow["room_id"] ?> class="btn btn-default">View detail</a>
                                            <?php if ($siteConfigurationObject->isUserLoggedIn()) : ?>
                                                <a href=<?php echo 'addToCart.php?room_id='.$datarow["room_id"] . "&returnURL=$returnURL&location=$location"?> class="btn btn-primary"><i class="fa fa-shopping-cart"></i>Add to cart</a>
                                            <?php endif; ?>
                                        </p>
                                    </div>
                                    <!-- /.text -->
                                	</div>
                                <!-- /.product -->
                            </div>
                        <?php endwhile;?>

                        </div>
                        <div class="row pages">
                        <ul class="pagination">
                            <?php if($rec_limit < $rec_count) : ?>
                            <?php 
                                $currQS = "?category=$category&location=$location"; 
                                if(isset($search)) {
                                    $currQS = "?search=$search&location=$location";
                                } 
                            ?>
                                <?php if($page == 1) : $next = $page + 1;?>
                                    <li><a href=<?php echo $PHP_SELF . "$currQS&sortBy=$sortBy&page=$next" ?> class="btn btn-primary btn-lg"><i class="fa fa-chevron-right"></i></a></li>
                                 <?php elseif($left_rec < $rec_limit ) : $last = $page - 1; ?>
                                    <li><a href=<?php echo $PHP_SELF . "$currQS&sortBy=$sortBy&page=$last" ?> class="btn btn-primary btn-lg"><i class="fa fa-chevron-left"></i></a></li>
                                <?php elseif($page > 1) : $next = $page + 1; $last = $page - 1;?>
                                    <li><a href=<?php echo $PHP_SELF . "$currQS&sortBy=$sortBy&page=$last" ?> class="btn btn-primary btn-lg"><i class="fa fa-chevron-left"></i></a></li>
                                    <li><a href=<?php echo $PHP_SELF . "$currQS&sortBy=$sortBy&page=$next" ?> class="btn btn-primary btn-lg"><i class="fa fa-chevron-right"></i></a></li>
                                <?php endif;?>
                            <?php endif;?>
                        </ul>
                    </div>

                     </div>
                <!-- /.col-md-9 -->
            </div>
            <!-- /.container -->
        </div>
        <!-- /#content -->

<?php
require("footer.php");
?>