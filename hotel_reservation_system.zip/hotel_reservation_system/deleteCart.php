<?php
    require_once("site_configuration.php");
    $conn = mysqli_connect("localhost","root","root","hotel_reservation_system", 3309);

    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
        echo "Database Connection Error";
    } 
    $purchase_id = $_GET["purchase_id"];
    $quantity = 0;
    $user_id = $siteConfigurationObject->getUserId();
    $query = "select totalroombook from roombook where purchase_id = $purchase_id";
    
    $result = $siteConfigurationObject->runSelectQuery($query);

    if($result["success"]){
        $row = mysqli_fetch_array($result["data"]);
        $quantity = $row["totalroombook"];
    }

    if($quantity > 1)
        $sql = "UPDATE roombook SET totalroombook=$quantity - 1 where purchase_id = $purchase_id";
    else
        $sql = "delete from rombook where purchase_id = $purchase_id";

    $conn->query($sql);
    $conn->close();
    header("Location: basket.php");
?>