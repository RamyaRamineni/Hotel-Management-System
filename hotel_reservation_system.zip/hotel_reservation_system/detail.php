<?php
require("topMenu.php");

$conn = mysqli_connect("localhost","root","root","hotel_reservation_system", 3309);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
    echo "Database Connection Error";
}
else{
if(isset($_GET['roomId']))   
    $room_id = $_GET['roomId'];
else {
    $room_id = 0;
}
     $sql = "SELECT * FROM rooms where room_id = '$room_id'";
     $result = mysqli_query($conn, $sql);
     if(! $result ) {
            die('Could not get data: ' . mysqli_error());
    }
}

$datarow = mysqli_fetch_array($result);

$url = "$_SERVER[REQUEST_URI]";
$path = parse_url($url, PHP_URL_PATH);
$qs = parse_url($url, PHP_URL_QUERY);
$returnURL = $path;
if(isset($qs))
    $returnURL .= "?$qs";
$returnURL = urlencode($returnURL);

?>

 <div id="all">

        <div id="content">
            <div class="container">

                <div class="col-md-12">
                    <ul class="breadcrumb">
                        <li><a href="#">Home</a>
                        </li>
                        <li><a href="#">Category</a>
                        </li>
                        <li><?php echo $datarow["room_type"] ?></li>
                    </ul>

                </div>

                <div class="col-md-3">
                    <!-- *** MENUS AND FILTERS ***
 _________________________________________________________ -->
                    <div class="panel panel-default sidebar-menu">

                        <div class="panel-heading">
                            <h3 class="panel-title">Categories</h3>
                        </div>

                        <div class="panel-body">
                            <ul class="nav nav-pills nav-stacked category-menu">
                                <li>
                                    <a href="category.php?category=0">All Rooms </a>
                                </li>
                                <li>
                                    <a href="category.php?category=1">Single Room </a>
                                </li>
                                <li>
                                    <a href="category.php?category=2">Double Room</a>
                                </li>
                                <li>
                                    <a href="category.php?category=3">Suite</a>
                                </li>
                                <li>
                                    <a href="category.php?category=4">Premium Room</a>
                                </li>
                                <li>
                                    <a href="category.php?category=5">Deluxe Room</a>
                                </li>
                            </ul>

                        </div>
                    </div>
                </div>

                <div class="col-md-9">
                    <div class="row" id="productMain">
                        <div class="col-sm-6">
                            <div id="mainImage">
                                <img src="<?php echo "img/products/$datarow[image]" ?>" alt="" class="img-responsive" style="height:500px;width:400px;">
                            </div>

                        </div>
                        <div class="col-sm-6">
                            <div class="box">
                                <h2 class="text-center"><?php echo $datarow["room_type"] ?></h2>
                                <p class="goToDescription"><a href="#details" class="scroll-to">Scroll to room details</a>
                                </p>
                                <p class="price">$<?php echo $datarow["price"] ?></p>

                                <p class="text-center buttons">
                                    <?php if ($siteConfigurationObject->isUserLoggedIn() && !$siteConfigurationObject->isUserAdmin()) : ?>
                                        <a href=<?php echo 'addToCart.php?roomId='.$datarow["room_id"] . "&returnURL=$returnURL" ?> class="btn btn-primary"><i class="fa fa-shopping-cart"></i>Add to cart</a>
                                    <?php endif; ?>
                                   
                                    <?php if ($siteConfigurationObject->isUserAdmin()) : 
                                               if ($datarow["status"] == "1") : ?>
                                                    <a href=<?php echo 'deleteProduct.php?roomId='.$datarow["room_id"] . "&returnURL=$returnURL&status=0" ?> class="btn btn-primary"><i class="fa fa-shopping-cart"></i>Disable Product</a>
                                                <?php else :?>
                                                    <a href=<?php echo 'deleteProduct.php?roomId='.$datarow["room_id"] . "&returnURL=$returnURL&status=1" ?> class="btn btn-primary"><i class="fa fa-shopping-cart"></i>Enable Product</a>
                                    <?php endif; 
                                        endif;?>
                                </p>


                            </div>
                           
                        </div>

                    </div>


                    <div class="box" id="details">
                        <p>
                            <h4>Room details</h4>
                            <?php if ($siteConfigurationObject->isUserAdmin()) : ?>
                                <form id="newProductForm" action="updateProductInfo.php" method="post" enctype="multipart/form-data">
                                    <div class="row">
                                        <input type="hidden" name="roomid" value=<?php echo $datarow["room_id"] ?> >

                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label for="roomtype">Room Type<span class="required">*</span>
                                                </label>
                                                <input type="text" class="form-control" id="roomtype" name="roomtype" value="<?php echo $datarow["room_type"] ?>">
                                            </div>
                                        </div>

                                    </div>

                                    <div class="row">
                                        <div class="col-sm-2">
                                            <div class="form-group">
                                                <label for="price">Price <span class="required">*</span>
                                                </label>
                                                <input type="text" class="form-control" id="price" name="price" value="<?php echo $datarow["price"] ?>">
                                            </div>
                                        </div>
                                        <div class="col-sm-2">
                                            <div class="form-group">
                                                <label for="available">Quantity <span class="required">*</span>
                                                </label>
                                                <input type="text" class="form-control" id="available" name="available" value="<?php echo $datarow["total_room"] ?>">
                                            </div>
                                        </div>
                                        <div class="col-sm-8">
                                            <div class="form-group">
                                                <label class="control-label">Select File</label>
                                                <input type="file" class="file" id="fileToUpload" name="fileToUpload">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-8">
                                            <div class="form-group">
                                                <label for="description">Category <span class="required">*</span>
                                                </label>
                                                <select class="form-control" id="category" name="category[]" multiple="multiple" title="hold ctrl or shift (or drag with the mouse) to select more than one.">
                                                    <?php 
                                                        $query = "SELECT C.category_id, C.category_name, crt.room_id  FROM Category C LEFT JOIN Category_ref_table crt
                                                                    ON c.category_id = crt.category_id AND crt.room_id = $room_id";

                                                        $result = $siteConfigurationObject->runSelectQuery($query);
                                                        if($result["success"]){
                                                            while($row = mysqli_fetch_array($result["data"])){
                                                                if(isset($row["room_id"]))
                                                                    echo "<option value=\"$row[category_id]\" selected=\"true\">$row[category_name]</option>";
                                                                else
                                                                    echo "<option value=\"$row[category_id]\">$row[category_name]</option>";
                                                            }
                                                        }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>


                                    <div class="row">
                                        <div class="col-sm-12">
                                            <div class="form-group">
                                                <label for="description">Room Description <span class="required">*</span>
                                                </label>
                                                <textarea class="form-control" id="description" name="description" rows="4"><?php echo $datarow["descriptions"] ?></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-2">
                                            <div class="form-group">
                                                <label for="occupancy">Occupancy<span class="required">*</span>
                                                </label>
                                                <input type="text" class="form-control" id="occupancy" name="occupancy" value="<?php echo $datarow["occupancy"] ?>">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-12 text-right">
                                            <button class="btn btn-primary" name="submitForm" type="submit"><i class="fa fa-plus"></i> Save Changes</button>
                                        </div>
                                    </div>


                                </form>
                            <?php else : ?>
                                <blockquote>
                                <p><em><?php echo nl2br($datarow["descriptions"]) ?></em></p></blockquote>
                                <h4>In Stock : <?php echo $datarow["total_room"] ?></h4>
                            <?php endif;?>
                            
                            <!--<h4>Size & Fit</h4>
                            <ul>
                                <li>Regular fit</li>
                                <li>The model (height 5'8" and chest 33") is wearing a size S</li>
                            </ul>

                            <blockquote>
                                <p><em>Define style this season with Armani's new range of trendy tops, crafted with intricate details. Create a chic statement look by teaming this lace number with skinny jeans and pumps.</em>
                                </p>
                            </blockquote>-->

                            <hr>
                            <div class="social">
                                <h4>Show it to your friends</h4>
                                <p>
                                    <a href="#" class="external facebook" data-animate-hover="pulse"><i class="fa fa-facebook"></i></a>
                                    <a href="#" class="external gplus" data-animate-hover="pulse"><i class="fa fa-google-plus"></i></a>
                                    <a href="#" class="external twitter" data-animate-hover="pulse"><i class="fa fa-twitter"></i></a>
                                    <a href="#" class="email" data-animate-hover="pulse"><i class="fa fa-envelope"></i></a>
                                </p>
                            </div>
                    </div>

                    
                </div>
                <!-- /.col-md-9 -->
            </div>
            <!-- /.container -->
        </div>
        <!-- /#content -->
        
<?php
require("footer.php");
?>
