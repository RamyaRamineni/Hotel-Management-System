function validateForm(form) {
		var checkInDate = form.checkin.value;
		var checkOutDate = form.checkout.value;
		var adultNum = form.adults.value;
		var childrenNum = form.children.value;
		var currentDate = new Date();
		var checkInDateArr = checkInDate.split("-");
		var checkInDateNew = new Date(checkInDateArr[0], checkInDateArr[1]-1, checkInDateArr[2]);
		var checkOutDateArr = checkOutDate.split("-");
		var checkOutDateNew = new Date(checkOutDateArr[0], checkOutDateArr[1]-1, checkOutDateArr[2]);		
			if(checkInDate == '' || checkOutDate == '') 
			{
				
				alert("Please choose date");
			 	return false;
			}

			if (checkInDateNew < currentDate || checkOutDateNew < currentDate)
			{
				alert("Check In and check out dates should not be lesser than today's date");
			 	return false;	
			}
			if(adultNum == 0) 
			{
			 	if(childrenNum == 0) 
				{				
				 alert("Please choose no. of guest");
				 return false;
				}
			}
			if(childrenNum == 0) 
			{
			 	if(adultNum == 0) 
				{
				 alert("Please choose no. of guest");
				 return false;
				}
			}
			if (checkInDate>checkOutDate)
			{
				alert("please choose proper check in and check out dates");
				return false;
			}

	}
