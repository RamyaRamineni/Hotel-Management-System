<?php
	require_once("site_configuration.php");
	//$roomid = $_POST["roomid"];
	
	
	$roomid = $_POST["roomid"];
	$roomtype = $_POST["roomtype"];
	$description = $_POST["description"];
	$price = $_POST["price"];
	$status = 1;
	$available = $_POST["available"];
	$location = $_POST["location"];
	$occupancy = $_POST["occupancy"];
	
	if($available == 0)
		$status = 0;

	if($roomid == "new")
		$returnURL = "addNewProduct.php";
	else
		$returnURL = "detail.php?roomId=$roomid";

	if($location == "Austin")
		$hotelid = 1;
	else 
		$hotelid = 2;
	echo "CHECK" . $roomid .$location . $hotelid;

	$target_dir = "img/products/";
	$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
	$imageName = basename($_FILES["fileToUpload"]["name"]);
	$error_code = $_FILES["fileToUpload"]["error"];
	$uploadOk = 0;

	if($error_code == 0 || (isset($imageName) && !empty($imageName))){

		$uploadOk = 1;
		$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
		// Check if image file is a actual image or fake image
		if(isset($_POST["submitForm"])) {
		    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
		    if($check !== false) {
		        echo "File is an image - " . $check["mime"] . ".";
		        $uploadOk = 1;
		    } else {
		        echo "File is not an image.";
		        $uploadOk = 0;
		    }
		}
		// Check if file already exists
		if (file_exists($target_file)) {
		    echo "Sorry, file already exists.";
		    $uploadOk = 0;
		}
		// Check file size 
		if ($_FILES["fileToUpload"]["size"] > 500000) {
		    echo "Sorry, your file is too large.";
		    $uploadOk = 0;
		}
		// Allow certain file formats
		if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
		&& $imageFileType != "gif" ) {
		    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
		    $uploadOk = 0;
		}
		// Check if $uploadOk is set to 0 by an error
		if ($uploadOk == 0) {
		    echo "Sorry, your file was not uploaded.";
		// if everything is ok, try to upload file
		} else {
		    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
		        echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
		    } else {
		        echo "Sorry, there was an error uploading your file.";

		    }
		}
	}

    if($siteConfigurationObject->isUserLoggedIn()){
	    if(!$siteConfigurationObject->initializeConnection()){
			$siteConfigurationObject->errorHandler("Database Login Failure.");
			//header("Location:accountDetails.php");
			//exit();
    		$siteConfigurationObject->gotoURL($returnURL);
    }
	
		$user_id = $siteConfigurationObject->getUserId();
		
		if($uploadOk == 1){
	    	if($roomid == "new") {
				$query="INSERT INTO ROOMS (room_type, descriptions, total_room, price, image, status, hotel_id, occupancy) 
						VALUES('$roomtype', '$description', $available, $price, '$imageName', $status, $hotelid, $occupancy)";
	    	}
			else {
				$query="UPDATE ROOMS SET room_type='$roomtype', descriptions='$description', total_rooms=$available, hotel_id = '$hotelid' price=$price, image='$imageName', status=$status WHERE room_id=$roomid";
			}
	    }else{
	    	if($roomid == "new") {
				$query="INSERT INTO ROOMS (room_type, descriptions, total_room, price, status, hotel_id, occupancy) 
						VALUES('$roomtype', '$description', $available, $price, $status, $hotelid, $occupancy)";
						
	    	}
			else {
				$query="UPDATE ROOMS SET room_type='$roomtype', descriptions='$description', total_room=$available, price=$price, status=$status, occupancy = $occupancy WHERE room_id=$roomid";
			}
	    }	    	
	
	 
        if(!mysqli_query($siteConfigurationObject->connection, $query)){
			$siteConfigurationObject->dbErrorHandler("Failed to update product details.");
    		$siteConfigurationObject->gotoURL($returnURL);
		}
		
		
		if($roomid == "new"){
			$query = "SELECT MAX(room_id) AS maxId FROM ROOMS";
			$result = mysqli_query($siteConfigurationObject->connection, $query);
			$result = mysqli_fetch_array($result);
			$roomid = $result["maxId"];
		}
	
		if($roomid != "new"){
			$query = "DELETE FROM CATEGORY_REF_TABLE WHERE room_Id = $roomid";
			mysqli_query($siteConfigurationObject->connection, $query);
	    }

	    foreach ($_POST["category"] as $value) {
			$query="INSERT INTO CATEGORY_REF_TABLE (category_id, room_id) VALUES('$value', '$roomid')";
			mysqli_query($siteConfigurationObject->connection, $query);
		}


	}
	
	$returnURL = "detail.php?roomId=$roomid";

   $siteConfigurationObject->gotoURL($returnURL);

   
?>