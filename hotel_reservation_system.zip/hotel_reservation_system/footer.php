
<style>
#copyright {
    position: fixed;
    left: 0;
    bottom: 0;
    width: 100%;
    background-color: grey;
    color: white;
    text-align: center;
}
</style>
        <!-- *** FOOTER ***
 _________________________________________________________ -->
        
        <!-- /#footer -->

        <!-- *** FOOTER END *** -->




        <!-- *** COPYRIGHT ***
 _________________________________________________________ -->
        <div id="copyright">
            <div class="container">
                <div class="col-md-12">
                    <p>© 2018 Taj Hotel.</p>

                </div>
            </div>
        </div>
        <!-- *** COPYRIGHT END *** -->


</body>

</html>
