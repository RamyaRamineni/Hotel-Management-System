<?php
	require_once("site_configuration.php");
	$room_id = $_GET["roomId"];
    $returnURL = $_GET["returnURL"];
    $status = $_GET["status"];


    if($siteConfigurationObject->isUserLoggedIn()){
	    if(!$siteConfigurationObject->initializeConnection()){
			$siteConfigurationObject->errorHandler("Database Login Failure.");
			return false;
	    }

		$user_id = $siteConfigurationObject->getUserId();
	    
		$query="UPDATE rooms SET status=$status where room_id = $room_id ";

        if(!mysqli_query($siteConfigurationObject->connection, $query)){
			$siteConfigurationObject->dbErrorHandler("Failed to add item to cart.");
			$error_message = "Failed to add item to cart";
			
			return false;
		}

	}

    $siteConfigurationObject->gotoURL($returnURL);
?>