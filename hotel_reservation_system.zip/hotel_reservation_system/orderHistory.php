<?php require('topMenu.php');

    $userid = $siteConfigurationObject->getUserId();
  
    $query = "SELECT BD.BOOKING_ID as BOOKING_ID, DATE(OM.ORDER_DATE) ORDER_DATE, DATE(BD.CHECKOUT_DATE) CHECKOUT_DATE, DATE(BD.CHECKIN_DATE) CHECKIN_DATE, ORDER_BY, ROUND(SUM(BK.PRICE * BK.QUANTITY), 2) AS TOTAL FROM BOOKING_DATES as BD JOIN BOOKINGS as BK JOIN ORDERS_MAIN AS OM WHERE OM.ORDER_BY = $userid AND BD.BOOKING_ID = BK.BOOKING_ID AND ORDER_ID =BD.BOOKING_ID GROUP BY BD.BOOKING_ID ORDER BY ORDER_ID DESC";
    $result = $siteConfigurationObject->runSQLQuery($query);

    if($result["success"]){
        $ORDERS = $result["data"];
        $NO_OF_ORDERS = $result["rows"];
    }
?>
   <div id="all">

        <div id="content">
            <div class="container">

                <div class="col-md-12">

                    <ul class="breadcrumb">
                        <li><a href="#">Home</a>
                        </li>
                        <li>My orders</li>
                    </ul>

                </div>

                <div class="col-md-3">
                    <!-- *** CUSTOMER MENU ***
 _________________________________________________________ -->
                     <div class="panel panel-default sidebar-menu">

                        <div class="panel-heading">
                            <h3 class="panel-title">Customer section</h3>
                        </div>

                        <div class="panel-body">

                            <ul class="nav nav-pills nav-stacked">
                                <li>
                                    <a href="accountDetails.php"><i class="fa fa-user"></i> My account</a>
                                </li>
                                <li class="active">
                                    <a href="orderhistory.php"><i class="fa fa-list"></i> My orders</a>
                                </li>
                                <?php if ($siteConfigurationObject->isUserAdmin()) : ?>
                                    <li>
                                        <a href="addNewProduct.php"><i class="fa fa-plus"></i> Add New Product</a>
                                    </li>
                                <?php endif;?>
                                <li>
                                    <a href="index.php?logOut=1"><i class="fa fa-sign-out"></i> Logout</a>
                                </li>
                            </ul>
                        </div>

                    </div>
                    <!-- /.col-md-3 -->

                    <!-- *** CUSTOMER MENU END *** -->
                </div>

                <div class="col-md-9" id="customer-orders">
                    <div class="box">
                        <h1>My orders</h1>
                        <p class="text-muted">If you have any questions, please feel free to <a href="contact.html">contact us</a>, our customer service center is working for you 24/7.</p>
                        <hr>
                        <?php if(isset($ORDERS) && $NO_OF_ORDERS > 0) : ?>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Order Number</th>
                                            <th>Placed on</th>
                                            <th>Order Total</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while($mainOrderRow = mysqli_fetch_array($ORDERS)) : ?>
                                            <tr>
                                                <td><?php echo $mainOrderRow["BOOKING_ID"] ?></td>
                                                <td><?php echo $mainOrderRow["ORDER_DATE"] ?></td>
                                                <td>$ <?php echo $mainOrderRow["TOTAL"] ?></td>
                                                <td><?php if(isset($mainOrderRow["CHECKIN_DATE"]) && !empty($mainOrderRow["CHECKIN_DATE"])) 
                                                                echo "Booked from $mainOrderRow[CHECKIN_DATE] to $mainOrderRow[CHECKOUT_DATE] ";
                                                            else
                                                                echo "Processing";
                                                    ?>
                                                </td>
                                            </tr>
                                            <?php
                                                $query = "SELECT ROOMS.ROOM_TYPE, BK.PRICE, BK.QUANTITY, ROUND((BK.PRICE * BK.QUANTITY), 2) AS TOTAL
                                                            FROM BOOKINGS BK
                                                            JOIN BOOKING_DATES BD ON BD.ORDER_ID = BK.ORDER_ID
                                                            JOIN ROOMS ON BK.ROOM_ID = ROOMS.ROOM_ID
                                                            WHERE BK.ORDER_ID = $mainOrderRow[ORDER_ID]";
                                                $result = $siteConfigurationObject->runSQLQuery($query);
                                                if($result["success"]){
                                                    $ORDER_DETAILS = $result["data"];
                                                    $NO_OF_ORDER_DETAILS = $result["rows"];
                                                }
                                            ?>
                                            <?php if(isset($ORDER_DETAILS) && $NO_OF_ORDER_DETAILS > 0) : ?>
                                            <tr>
                                                <td colspan="4">
                                                <div class="table-responsive">
                                                    <table class="table table-bordered">
                                                        <thead>
                                                            <tr>
                                                                <th>Name</th>
                                                                <th>Price</th>
                                                                <th>Quantity</th>
                                                                <th>Total</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php while($orderDetailsRow = mysqli_fetch_array($ORDER_DETAILS)) : ?>
                                                                <tr>
                                                                    <td><?php echo $orderDetailsRow[ROOM_TYPE] ?></td>
                                                                    <td>$ <?php echo $orderDetailsRow["PRICE"] ?></td>
                                                                    <td><?php echo $orderDetailsRow["QUANTITY"] ?></td>
                                                                    <td>$ <?php echo $orderDetailsRow["TOTAL"] ?></td>
                                                                </tr>
                                                            <?php endwhile;?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                                </td>
                                            </tr>
                                            <?php endif;?>
                                        <?php endwhile;?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else : echo "You did not place any orders ...";?>
                        <?php endif;?>
                    </div>
                </div>

            </div>
            <!-- /.container -->
        </div>
        <!-- /#content -->




    </div>
    <!-- /#all -->

<?php include 'footer.php';?>