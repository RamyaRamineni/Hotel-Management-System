<?php
require_once("configuration_helper.php");
session_start();
$temp = "this is a temp variable";
$siteConfigurationObject = new SiteConfiguration();

$siteConfigurationObject->setWebsiteName('hotels.com');

$siteConfigurationObject->initializeDatabase('localhost', 'hotel_reservation_system', 'root', 'root', 'UserLogin');

if(!$siteConfigurationObject->isUserLoggedIn())
	$siteConfigurationObject->setRandomKey();
?>
