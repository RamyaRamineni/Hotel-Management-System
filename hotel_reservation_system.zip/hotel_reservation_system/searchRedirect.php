<?php
	require_once("site_configuration.php");
	$searchValue = urlencode("$_POST[searchValue]");
	if(isset($_GET["location"]) && !empty(trim($_GET["location"]))){
	    $location = $_GET["location"];
	}
    $siteConfigurationObject->gotoURL("category.php?search=$searchValue&location=$location");
?>