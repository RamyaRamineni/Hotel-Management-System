<?php
	require_once("site_configuration.php");
	$room_id = $_GET["room_id"];
    $returnURL = $_GET["returnURL"];
    $location = $_GET["location"];
    
    if(isset($_GET["qty"]))
    	$qty = $_GET["qty"];
    else
    	$qty = 1;
    
    $returnURL = $returnURL."?location=".$location;
   
	$user_id = $siteConfigurationObject->getUserId();

    $query = "SELECT * FROM roombook WHERE room_id = $room_id AND user_id = $user_id AND status = 0";
    $result = $siteConfigurationObject->runSelectQuery($query);
    if($result["success"]){
	    if($result["rows"] > 0){
	        while($row = mysqli_fetch_array($result["data"])){
	        	$Quantity = $row["totalroombook"];
	        	$Quantity += $qty;
	            $query = "UPDATE roombook SET totalroombook = $Quantity WHERE purchase_id = $row[purchase_id]";
	        }
	    }
	    else{
			$query="INSERT INTO roombook(user_id, status, totalroombook, room_id) VALUES ($user_id, 0, $qty, $room_id)";
	    }
	    echo $query;
	    if($siteConfigurationObject->isUserLoggedIn()){
		    if(!$siteConfigurationObject->initializeConnection()){
				$siteConfigurationObject->errorHandler("Database Login Failure.");			
				return false;
		    }

	        if(!mysqli_query($siteConfigurationObject->connection, $query)){
				$siteConfigurationObject->dbErrorHandler("Failed to add item to cart.");
				$error_message = "Failed to add item to cart";				
				return false;
			}
			$cartCount = $siteConfigurationObject->getCartQuantity();
			$cartCount += $qty;
			$siteConfigurationObject->setCartQuantity($cartCount);

		}
	}
	$returnURL = $returnURL . "&location=". $location;
    $siteConfigurationObject->gotoURL($returnURL);
?>