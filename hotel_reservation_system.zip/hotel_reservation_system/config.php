<?php
	$servername = "localhost";
	$username = "root";
	$password = "root";
	$port = "3309";
	$db = "hotel_reservation_system";
	$conn = mysqli_connect($servername, $username, $password, $db, $port);

	// Check connection
	if (!$conn) {
	    die("Connection failed: " . mysqli_connect_error());	
	}	
?>