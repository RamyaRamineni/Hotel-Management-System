<?php
require("topMenu.php");
?>
	<body>
		<h1> ABOUT US</h1>
		<h3>
			<p>We are Taj hotels. We were founded in 1984 and we value customer experience.</p>
			<p>Established in 1984, Taj Hotels Palaces Resorts Safaris is one of Texas largest and finest group of hotels, comprising hotels in 2 locations across the texas, including presence in Austin and Dallas.  Each Taj hotel offers an unrivalled fusion of warm  hospitality, world-class service and modern luxury.
		</h3>
		<img src="img/taj.jpg"  height="600" width="600" style="margin-left: 350px;">
	</body>


<?php
require("footer.php");
?>

</html>