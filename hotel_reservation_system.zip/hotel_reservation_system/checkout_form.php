

<?php
    require_once("site_configuration.php");
    $servername = "localhost";
    $username = "root";
    $password = "root";
    $dbname = "hotel_reservation_system";
    $conn = new mysqli($servername, $username, $password, $dbname, 3309);
    $userid = $siteConfigurationObject->getUserId();
    $checkin = $siteConfigurationObject->getCheckin();
    $checkout = $siteConfigurationObject->getCheckout();
    $c1 = date_create("$checkout");
    $c2 = date_create("$checkin");
    $diff = date_diff($c2,$c1);
    $date_d = $diff->format("%a");    
    $sql = "INSERT INTO ORDERS_MAIN(ORDER_BY) VALUES($userid)";
    $result = $siteConfigurationObject->runSQLQuery($sql);
    if($result["success"]){

        $sql = "SELECT MAX(ORDER_ID) ORDER_ID FROM ORDERS_MAIN WHERE ORDER_BY = $userid";
        $result = $siteConfigurationObject->runSQLQuery($sql);
        if($result["success"]){
            $dataRow = mysqli_fetch_array($result["data"]);
            $order_id = $dataRow["ORDER_ID"];            
            $sql = "SELECT P.*, T.price FROM roombook P JOIN rooms T ON P.room_id = T.room_id WHERE USER_ID = $userid AND P.STATUS = 0";
            
            $purchased_result = $siteConfigurationObject->runSQLQuery($sql);
            if($purchased_result["success"]){
                while($dataRow = mysqli_fetch_array($purchased_result["data"])){
                    $purchase_id = $dataRow["purchase_id"];
                    $user_id = $dataRow["user_id"];
                    $price = $dataRow["price"];
                    $quantity = $dataRow["totalroombook"];
                    $room_id =  $dataRow["room_id"];
                    $occupants = 2;
                    $total_price = $price*$date_d;
                                        
                    $sql = "INSERT INTO bookings (booking_id, room_id, PURCHASE_ID, PRICE, QUANTITY)
                            VALUES($order_id, $user_id, $purchase_id, $total_price, $quantity)";
                    
                    $order_details_result = $siteConfigurationObject->runSQLQuery($sql);
                    if($order_details_result["success"]){
                       $sql = "UPDATE roombook SET status = 1 WHERE user_id = $userid and status = 0 and purchase_id=$purchase_id";
                        $update_purchase_result = $siteConfigurationObject->runSQLQuery($sql);
                    }
                    $sql = "INSERT INTO booking_dates (booking_id, checkin_date, checkout_date, occupants)
                            VALUES($order_id, '$checkin', '$checkout', $occupants)";                    
                    $result = $siteConfigurationObject->runSQLQuery($sql);

                    $sql = "UPDATE rooms SET  total_room = total_room - 1 WHERE room_id = $room_id";
                    $result = $siteConfigurationObject->runSQLQuery($sql);
                }
            }

        }
    }

    
   header("Location: orderHistory.php");
?>

