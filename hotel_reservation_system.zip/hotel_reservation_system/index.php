<?php
require("topMenuIndex.php");

?>

    <div id="all">
        <?php if ($siteConfigurationObject->isUserLoggedIn()) : ?>
            <div data-animate="fadeInDown">
                <div class="container">
                    <ul class="breadcrumb">
                        <li><a href="#">Welcome <strong><?php echo $siteConfigurationObject->getUserFullName(); ?></strong></a>
                        </li>
                    </ul>
                </div>
            </div>
        <?php endif;?>
        <?php if (!empty($siteConfigurationObject->getErrorMessage())) : ?>
            <div id="content" data-animate="fadeInDown">
                <div class="container">
                    <div class="alert alert-danger">
                        <strong><?php echo $siteConfigurationObject->getErrorMessage(); ?></strong>
                    </div>
                </div>
            </div>
        <?php endif;?>

            

            <!-- *** ADVANTAGES HOMEPAGE ***
 _________________________________________________________ -->
            
            <!-- *** ADVANTAGES END *** -->

            <!-- *** HOT PRODUCT SLIDESHOW ***
 _________________________________________________________ -->
            
            <!-- *** HOT END *** -->\


        </div>
        <div>

        </div>
        <div class="center">
    <form name="form" action="category.php" method="post" onSubmit="return validateForm(this);">
            <div class="row">
                
                    <div class="large-6 columns" style="max-width:100%;">
                        <label>Check In
                            <input type = "date" name="checkin" id="checkin" style="width:100%;"/>
                        </label>
                    </div>
                    
                    <div class="large-6 columns" style="max-width:100%;">
                        <label>Check Out
                            <input type = "date" name="checkout" id="checkout" style="width:100%;"/>
                        </label>
                    
                    
                    </div>
                    
            </div>
            <div class="row">
                
                    <div class="large-6 columns">
                        <label class="fontcolor">Adults                            
                                <select  name="adults" id="adults" style="width:100%;">                                
                                <option value="1">1</option>
                                <option value="2">2</option>                                
                                </select>
                            
                        </label>
                    </div>
                    
                    <div class="large-6 columns"  style="max-width:100%;">
                        <label class="fontcolor">Children
                            <select  name="children" id="children" style="width:100%; color:black;">   
                            <option value="0">0</option>                         
                            <option value="1">1</option>
                            <option value="2">2</option>                            
                            </select>
                        </label>
                    </div>
                
                    <div class="large-6 columns"  style="max-width:100%;">
                        <label class="fontcolor">Location
                            <select  name="location" id="location" style="width:100%; color:black;">
                            <option value="Austin">Austin</option>
                            <option value="Dallas">Dallas</option>                          
                            </select>
                        </label>
                    </div>
            </div>
            <div class="large-6 columns" >
                <button name="submit" href="#" class="btn btn-info" value="Submit Button" style="background-color:#2ecc71;" >Check Availability</button>
            </div>
    </form>
</div>


        <!-- /#content -->
</body>
<?php
require("footer.php");
?>
</html>