<?php
require_once("site_configuration.php");

if(isset($_POST['loginModalSubmit'])){
    if(isset($_POST['loginModalSubmit'])){
        $email = trim($_POST['email-modal']);
        $password = trim($_POST['password-modal']);
        if($siteConfigurationObject->userLogin($email, $password)){
        }
    }
}
else if(isset($_POST['loginSubmit'])){
    if(isset($_POST['loginSubmit'])){
        $email = trim($_POST['loginEmail']);
        $password = trim($_POST['loginPassword']);
        if($siteConfigurationObject->userLogin($email, $password)){
        }
    }
}
else if(isset($_POST['registerSubmit'])){ 
    if($siteConfigurationObject->registerUser()){
    }
}
else if(isset($_GET['logOut'])){
 if($siteConfigurationObject->logOut()){
    } 
}

?>
<!DOCTYPE html> 
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="robots" content="all,follow">
    <meta name="googlebot" content="index,follow,snippet,archive">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Taj Hotels">
    <meta name="keywords" content="taj, hotel">

    <title>
        Taj Hotels
    </title>

    <link href='http://fonts.googleapis.com/css?family=Roboto:400,500,700,300,100' rel='stylesheet' type='text/css'>

    <!-- styles-->
    <link href="css/font-awesome.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/owl.carousel.css" rel="stylesheet">
    <link href="css/owl.theme.css" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/jquery.bootstrapvalidator/0.5.3/css/bootstrapValidator.css"/>

    <!-- theme stylesheet -->
    <link href="css/style.custom.css" rel="stylesheet" id="theme-stylesheet">

    <link href="css/custom.css" rel="stylesheet">
    <link href="css/layout.css" rel="stylesheet">

    <script src="js/respond.min.js"></script>

    <link rel="shortcut icon" href="favicon.png">
    <!-- *** SCRIPTS TO INCLUDE ***
 _________________________________________________________ -->
    <script src="js/jquery-1.11.0.min.js"></script>
    <!--<script src="js/bootstrap.min.js"></script>-->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery.bootstrapvalidator/0.5.3/js/bootstrapValidator.js"></script>
    <script src="js/jquery.cookie.js"></script>
    <script src="js/waypoints.min.js"></script>
    <script src="js/modernizr.js"></script>
    <script src="js/bootstrap-hover-dropdown.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/front.js"></script>
    <script src="js/validation.js"></script>


    <script src="js/formValidation.js"></script>

</head>

<body class = "index">
    <!-- *** TOPBAR ***
 _________________________________________________________ -->
    <div id="top">
        <div class="container">
            <div class="col-md-6 offer" data-animate="fadeInDown">
                <a href="#" class="btn btn-success btn-sm" data-animate-hover="shake">Offer of the day</a>  <a href="#">Get flat 15% off on bookings over $1000!</a>
            </div>
            <div class="col-md-6" data-animate="fadeInDown">
                <ul class="menu">
                    <?php if ($siteConfigurationObject->isUserLoggedIn()) : ?>
                        <li><a href="accountDetails.php"><?php echo 'Hello, ' . $siteConfigurationObject->getUserFullName(); ?></a>
                        </li>
                        <li><a href="accountDetails.php">My Account</a>
                        </li>
                       <li><a href="category.php">Rooms</a>
                        </li>
                        <li><a href="index.php?logOut=1">LogOut</a>
                        </li>
                    <?php else : ?>
                        <li><a href="#" data-toggle="modal" data-target="#login-modal">Login</a>
                        </li>
                        <li><a href="register.php">Register</a>
                        </li>
                    <?php endif;?>                    
                </ul>
            </div>
        </div>
        <div class="modal fade" id="login-modal" tabindex="-1" role="dialog" aria-labelledby="Login" aria-hidden="true">
            <div class="modal-dialog modal-sm">

                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title" id="Login">Customer login</h4>
                    </div>
                    <div class="modal-body">
                        <form action="<?php echo $_SERVER['REQUEST_URI']; ?>" method="post" id="loginModalForm">
                            <input type='hidden' name='loginModalSubmit' id='loginModalSubmit' value='1'/>
                            <div class="form-group">
                                <div class="inputGroupContainer">
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="glyphicon glyphicon-envelope"></i></span>
                                        <input type="text" class="form-control" name="email-modal" id="email-modal" placeholder="E-Mail Address">
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="inputGroupContainer">
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                                        <input type="password" class="form-control" name="password-modal" id="password-modal" placeholder="password">
                                    </div>
                                </div>
                            </div>

                            <p class="text-center">
                                <button class="btn btn-primary" type="submit"><i class="fa fa-sign-in"></i> Log in</button>
                            </p>

                        </form>

                        <p class="text-center text-muted">Not registered yet?</p>
                        <p class="text-center text-muted"><a href="register.php"><strong>Register now</strong></a>! It is easy and done in 1&nbsp;minute and gives you access to special discounts and much more!</p>

                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- *** TOP BAR END *** -->

    <!-- *** NAVBAR ***
 _________________________________________________________ -->

    <div class="navbar navbar-default yamm" role="navigation" id="navbar">
        <div class="container">
            <div class="navbar-header">

                <a class="navbar-brand home" href="index.php" data-animate-hover="bounce">
                    <img id="logo" src="img/logo.jpeg" alt="Taj" class="hidden-xs">
                </a>
            </div> 
            <div class="navbar-header">
                <div class="navbar-buttons">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation">
                        <span class="sr-only">Toggle navigation</span>
                        <i class="fa fa-align-justify"></i>
                    </button>
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#search">
                        <span class="sr-only">Toggle search</span>
                        <i class="fa fa-search"></i>
                    </button>
                    <a class="btn btn-default navbar-toggle" href="basket.php">
                        <i class="fa fa-shopping-cart"></i>
                        <span class="hidden-xs">
                            <?php echo $siteConfigurationObject->getCartQuantity() . " item(s) in Cart" ?>
                        </span>
                    </a>
                </div>
            </div>          
            <!--/.navbar-header -->

            <div class="navbar-collapse collapse" id="navigation">

                <ul class="nav navbar-nav navbar-left">
                    <li><a href="index.php">Home</a>
                    </li>
                    <li><a href="about.php">About</a>
                    </li>
                    <li><a href="pictures.html">Gallery</a>
                    </li>
                    
                    
                    
                    
                </ul>
            
            </div>
            <!--/.nav-collapse -->

            
            <!--/.nav-collapse -->
        </div>
    </div>

            
<!--</body>-->



        
        <!-- /container -->
            
    <!-- /#navbar -->

    <!-- *** NAVBAR END *** -->
    


